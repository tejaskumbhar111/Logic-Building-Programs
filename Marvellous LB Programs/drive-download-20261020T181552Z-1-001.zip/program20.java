class program20
{
    public static void main(String A[])
    {
        System.out.println("Jay Ganesh..."); 
    }
}